import boto3
import json
import cv2
import numpy as np

s3=boto3.resource('s3')
client=boto3.client('rekognition')
response = client.detect_faces( Image={
    'S3Object': {
        'Bucket': 'emotiondetection',
        'Name':'football.jpg',
        },
    },Attributes=['ALL']
)
for i in response['FaceDetails']:
    x= int(i['BoundingBox']['Left']*img.shape[1])
    y=int(i['BoundingBox']['Top']*img.shape[0])
    w=int(i['BoundingBox']['Width']*img.shape[1])
    h=int(i['BoundingBox']['Height']*img.shape[0])
    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
cv2.rectangle(img,(0,0),(10,10),(255,0,0),2)
cv2.imshow ('img',img)
cv2.waitKey(0)
cv2.destroyAllWindows()

