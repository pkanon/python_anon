import boto3
import json
import cv2
import numpy as np

s3=boto3.resource('s3')
img = cv2.imread('football2.jpg')
client=boto3.client('rekognition')
response = client.detect_faces( Image={
    'S3Object': {
        'Bucket': 'emotiondetection',
        'Name':'football.jpg',
        },
    },Attributes=['ALL']
)
for i in response['FaceDetails']:
    print (i)
    print('\r\n \r\n')

