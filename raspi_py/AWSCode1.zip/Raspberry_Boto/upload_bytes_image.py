import boto3
import json
import cv2
import numpy as np
from PIL import Image
import io

s3=boto3.resource('s3')
img = cv2.imread('football2.jpg')
pil_image = Image.fromarray (img)
stream=io.BytesIO ()
pil_image.save(stream,format='JPEG')
bin_img=stream.getvalue()
img_bytes = np.frombuffer(img,np.uint16 )

client=boto3.client('rekognition')
response = client.detect_faces( Image={
    'Bytes': bin_img},Attributes=['ALL']
)
for i in response['FaceDetails']:
    #print (i['Emotions'])
    #print('\r\n \r\n')
    x= int(i['BoundingBox']['Left']*img.shape[1])
    y=int(i['BoundingBox']['Top']*img.shape[0])
    w=int(i['BoundingBox']['Width']*img.shape[1])
    h=int(i['BoundingBox']['Height']*img.shape[0])
    print(str(x) +','+str(y)+','+str(w)+','+str(h))
    print(img.shape)
    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
cv2.rectangle(img,(0,0),(100,10),(255,0,0),2)
cv2.imshow ('img',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
#response_dict = json.loads(response.read())
#print(response_dect.get('FaceDetails',{}).get('BoundingBox',{}))
#Sprint(response['FaceDetails'])
