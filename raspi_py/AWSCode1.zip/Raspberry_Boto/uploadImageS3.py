import boto3
import cv2


s3=boto3.resource('s3')
img = cv2.imread('football2.jpg')
data = open('football2.jpg','rb')
s3.Bucket ('emotiondetection').put_object(Key='football.jpg',Body=data)
